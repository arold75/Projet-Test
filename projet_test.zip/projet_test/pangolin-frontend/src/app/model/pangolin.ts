import { AmisNonInscrit } from './amisNoninscrit';

export interface Pangolin{
  login? : string;
  password? : string;
  _id? : string;
  race? : string;
  famille? : string;
  amis? : Pangolin[];
  nourriture? : string;
  age?: string;
  amisNonInscrit? : AmisNonInscrit[];
}
