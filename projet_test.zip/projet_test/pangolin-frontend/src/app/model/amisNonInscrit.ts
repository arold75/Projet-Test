export interface AmisNonInscrit{
  _id?:String;
  nom? : string;
  age?: string;
  famille? : string;
  race? : string;
  nourriture? : string;
}
