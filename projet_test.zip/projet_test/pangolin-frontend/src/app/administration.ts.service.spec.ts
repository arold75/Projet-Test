import { TestBed } from '@angular/core/testing';

import { Administration.TsService } from './administration.ts.service';

describe('Administration.TsService', () => {
  let service: Administration.TsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Administration.TsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
