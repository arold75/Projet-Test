import { Component, OnInit, Input, Output,EventEmitter } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Pangolin } from '../model/pangolin';
import { of, Observable} from 'rxjs';
import {switchMap} from 'rxjs/operators';
import { NgForm } from '@angular/forms';
import { AmisNonInscrit } from '../model/amisNoninscrit';

@Component({
  selector: 'app-carnet',
  templateUrl: './carnet.component.html',
  styleUrls: ['./carnet.component.css']
})
export class CarnetComponent implements OnInit{

  login : string;
  pangolin : Pangolin = {login :null,password : null};
  allPangolins:Pangolin[];
  pangolinFriends : Pangolin[] = [];
  pangolinFriendsNonInscrit : AmisNonInscrit[] = [];
  isModalShow : boolean= true;
  friends : Pangolin[]=[];
  utilisateur : Pangolin[]=[];
  elementSupprimer : string;


   postDataNi : Pangolin={
    amisNonInscrit:[{
      nom:"television",
      age:"16",
      famille:"juvisic",
      race:"palmisine",
      nourriture:"macabo"
    }]
  }


  url = 'http://localhost:3000/allPangolins';

  constructor(private router: Router , private http: HttpClient) { 
    // ajout de l'entête
    var node= document.getElementById("navbarCollapse")
    if(node!=undefined){
      node.setAttribute('id','navbarCollapses');
    }
  }

  ngOnInit(): void {
    this.http.get<Pangolin[]>(this.url).toPromise().then(data => {
        //recupere login
        this.login = JSON.parse(localStorage.getItem('pangolin')).login;
        //recuperer l'utilisateur pangolin connecté
        this.utilisateur = data.filter(pangolin => pangolin.login==this.login);
        //empecher le pangolin d'être dans son propre carnet d'adresses
        data=data.filter(item=>item.login!=this.login);
        this.allPangolins = data;

        //filtre distinct pour eviter duplicatat
        this.friends =[...new Set(this.utilisateur[0].amis)];
        
        //initialise liste d'amis
        this.friends.forEach(friend => {
          console.log('init id',friend);
            this.getPangolin(friend).subscribe(data=>{
              this.pangolinFriends.push(data);
            });
        });
    });
  }

  getPangolin(friend : any) : Observable<Pangolin>{
    return this.http.get<Pangolin>(`http://localhost:3000/${friend}`).pipe(switchMap((data:Pangolin) => {
        //this.pangolinFriends.push(data);
        console.log("nouveau ",this.pangolinFriends);
        return of(data);
    }));
  }

  ajouterAmi(id : string ){
   console.log("mon id: ",id);
  //recuperer ami pangolin ajouté
  var ami = this.allPangolins.filter(pangolin => pangolin._id==id);
   console.log("mon element ",this.utilisateur[0]._id);

   console.log("mon ami ",ami[0]);

    this.http.put(`http://localhost:3000/addfriend/${this.utilisateur[0]._id}/${id}`,ami[0]).subscribe((data:any) => {
      console.log("elemen test",data);
      document.getElementById(id).setAttributeNode(document.createAttribute('disabled'));
      this.getPangolin(id).subscribe(friend =>{
        this.pangolinFriends.push(friend);
      });
    });

      //
  }

  deletePangolin(id : string){
     this.elementSupprimer=id;
  }

  validateDelete(validate? : Boolean){
    if(validate){
        //recuperer ami selectionné
        var ami = this.allPangolins.filter(pangolin => pangolin._id==this.elementSupprimer);
          
        console.log("pangolin à suprimer ",ami[0]);
      
        this.http.put(`http://localhost:3000/deletefriend/${this.utilisateur[0]._id}/${this.elementSupprimer}`,ami[0]).subscribe((data:any) => {
          document.getElementById(this.elementSupprimer).removeAttribute('disabled');
          console.log('delete ',data);
          this.pangolinFriends=this.pangolinFriends.filter(item=>item._id!=this.elementSupprimer);
        });
    }
  }
  ajoutAmisNonInscrit(ami : NgForm){
    console.log(ami.value);
    
        this.http.put(`http://localhost:3000/addfriendNonIncrit/${this.utilisateur[0]._id}`,ami.value).subscribe((data:any) => {
          console.log('nouvel ami non inscrit ',data);
          this.getPangolin(this.utilisateur[0]._id).subscribe(ami =>{
          this.pangolinFriendsNonInscrit.push(ami);
          let element=ami.amisNonInscrit[ami.amisNonInscrit.length-1];

          let pangolinNonInscrit : Pangolin = {
            login : element.nom,
            race : element.race,
            famille : element.famille,
            nourriture : element.nourriture,
            age: element.age,
          }
          this.pangolinFriends.push(pangolinNonInscrit)
          })
      });
  }
}
