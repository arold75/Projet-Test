import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpHeaders
} from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class InterceptInterceptor implements HttpInterceptor {

  constructor() {}

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    if( JSON.parse(localStorage.getItem('pangolin'))!=null){
       const token = JSON.parse(localStorage.getItem('pangolin')).token;
       const headers = new HttpHeaders().set("x-access-token",token);
       const authRequest = request.clone({headers : headers});
       return next.handle(authRequest);
    }
    else{
      return next.handle(request);
    }
  }
}
