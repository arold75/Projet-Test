import { Component, Injectable} from '@angular/core';
import {HttpClient,HttpErrorResponse} from '@angular/common/http';
import {NgForm} from '@angular/forms';
import {Router} from '@angular/router'
@Component({
  selector: 'app-accueil',
  templateUrl: './accueil.component.html',
  styleUrls: ['./accueil.component.css']
})
@Injectable()
export class AccueilComponent {

  url = 'http://localhost:3000/login';
  urlInscription = 'http://localhost:3000/inscription';

  postData = {
    login: 'my content',
    password:'poid'
  };

  inscriptionData = {
    login: "le nom",
    password : 'le mdp',
    age: "l'age",
    famille: "la famille",
    race: "la race",
    nourriture: "la nourriture"
  } 
  json: any;

  constructor(private http: HttpClient , private router : Router) {
    // suppression de l'entête à la page d'accueil
    var node = document.getElementById('navbarCollapses');
    if(node!=undefined){
      node.setAttribute('id','navbarCollapse')
    }
  }

  ngOnDestroy(): void {
  }

//connexion 
onPangolin(pangolinForm : NgForm){
    console.log(pangolinForm);
    this.postData.login=pangolinForm.controls['pangolinName'].value;
    this.postData.password= pangolinForm.controls['pangolinPassword'].value;
    console.log(this.postData);
    this.http.post(this.url, this.postData).toPromise().then((data:any) => {
      if(data.auth==true){
        localStorage.setItem('pangolin',JSON.stringify({login:this.postData.login,token:data.token}));
        this.router.navigate(['./carnet']);
      }
    }).catch((err:HttpErrorResponse)=>{
      alert('login ou mot de passe erroné');
    });

}
//inscription
onInscription(inscriptionForm : NgForm){
  console.log(inscriptionForm);
  this.inscriptionData.login=inscriptionForm.controls['nom'].value;
  this.inscriptionData.age=inscriptionForm.controls['age'].value;
  this.inscriptionData.famille=inscriptionForm.controls['famille'].value;
  this.inscriptionData.nourriture=inscriptionForm.controls['nourriture'].value;
  this.inscriptionData.race=inscriptionForm.controls['race'].value;
  this.inscriptionData.password=inscriptionForm.controls['password'].value;
 console.log(this.inscriptionData);
  this.http.post(this.urlInscription, this.inscriptionData).toPromise().then((data:any) => {
    console.log(data);
    console.log(data.json);
    this.json = JSON.stringify(data.json);

    if(data.auth==true){
      localStorage.setItem('pangolin',JSON.stringify({login:this.inscriptionData.login,token:data.token}));
      this.router.navigate(['./carnet']);
    }
  }).catch((err:HttpErrorResponse)=>{
    alert('Erreur de création de compte');
  });
  }

}
