import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AccueilComponent } from './accueil/accueil.component';
import { AuthGuard } from './service/auth/auth.guard';
import { CarnetComponent } from './carnet/carnet.component';

const routes: Routes = [{ path: 'carnet',canActivate : [AuthGuard], component: CarnetComponent }];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers : [AuthGuard]
})
export class AppRoutingModule { }
