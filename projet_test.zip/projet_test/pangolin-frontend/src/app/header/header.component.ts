import { Component, OnInit,Input } from '@angular/core';
import { Router } from '@angular/router';
import { Pangolin } from '../model/pangolin';
import { HttpClient } from '@angular/common/http';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  login : string;
  url = 'http://localhost:3000/allPangolins';
  utilisateur : Pangolin[]=[];
  user :Pangolin = {login:null,password:null};
  
  json : any;

  updateData = {
    login: "le nom",
    age: "l'age",
    famille: "la famille",
    race: "la race",
    nourriture: "la nourriture"
  } 
  @Input() pangolinInfo : Pangolin;

  constructor(private router: Router, private http : HttpClient) { }

  ngOnInit(): void {
   
  }

  chargeProfile(){
    this.http.get<Pangolin[]>(this.url).toPromise().then(data => {
      //recupere login
      this.login = JSON.parse(localStorage.getItem('pangolin')).login;
      //recuperer l'utilisateur pangolin connecté
      this.utilisateur = data.filter(pangolin => pangolin.login==this.login);

      console.log('mon header user',this.utilisateur[0]);
      this.user=this.utilisateur[0];
    });
  }

  updateProfile(updateProfile : NgForm){
    console.log(updateProfile);
  this.updateData.login=this.user.login
  this.updateData.age=this.user.age
  this.updateData.famille=updateProfile.controls['famille'].value;
  this.updateData.nourriture=updateProfile.controls['nourriture'].value;
  this.updateData.race=updateProfile.controls['race'].value;
  console.log(this.updateData);
  this.http.put(`http://localhost:3000/${this.user._id}`, this.updateData).toPromise().then((data:any) => {
    console.log(data);
    console.log(data.json);
    this.json = JSON.stringify(data.json);
    alert("modification de profil effectuée avec success");
    location.reload();
  })
  }

  onTransmited(data : Pangolin){
  }

  // recuperation du login
  getPangolin(){
    if(JSON.parse(localStorage.getItem('pangolin'))!=null){
      return JSON.parse(localStorage.getItem('pangolin')).login;
    }else{
      return "Mon compte";
    }
  }

  logOut(){
    console.log('deconnexion');
    localStorage.removeItem('pangolin');
    this.router.navigate(['./accueil']);
  }
}
