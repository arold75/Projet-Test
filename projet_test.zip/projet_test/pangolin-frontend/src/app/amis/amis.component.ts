import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-amis',
  templateUrl: './amis.component.html',
  styleUrls: ['./amis.component.css']
})
export class AmisComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
