import { Injectable } from '@angular/core';
import {HttpClient,HttpErrorResponse} from '@angular/common/http';
import {Observable} from 'rxjs';
import {Pangolin} from 'model/pangolin'

@Injectable({
  providedIn: 'root'
})
export class Administration.TsService {

  constructor(private httpclient : HttpClient) {
  }

  public addPangolin = (pango : Pangolin) : Observable<number> =>{
    return this.httpclient.post<number>('/register',pango);
  }
}
