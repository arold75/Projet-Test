const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
var helmet = require('helmet');

const { mongoose } = require('./db.js');
var pangolinController = require('./controllers/pangolinController');

// Initialising application
var app = express();
app.use(bodyParser.json());
app.use(cors());
app.use(helmet());
app.disable('x-powered-by');
app.use(function (req, res, next) {
    console.log('Time:', Date.now());
    next();
});

// Server listening on port 3000
app.listen(3000, () => console.log('Server started at port : 3000'));

// Routes
app.use('/', pangolinController);
app.use('/logout', function (req, res) {
  res.status(200).send({ auth: false, token: null });
});