**Installation Instructions**


1. Install MongoDB **https://www.mongodb.com/download-center/compass**
2. Install Mongo Compass **https://docs.mongodb.com/manual/tutorial/install-mongodb-on-windows**
3. Clone the repository
4. Run **npm install**
5. Run **nodemon index.js**



**Usage Instructions**

**Endpoints**
1. Pangolin endpoint **localhost:3000/**
