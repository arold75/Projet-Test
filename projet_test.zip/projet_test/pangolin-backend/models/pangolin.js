const mongoose = require('mongoose');
const Schema = mongoose.Schema;
var ObjectId = require('mongoose').Types.ObjectId;

var pangolinSchema = new Schema({
    login: { 
        type: String,
        required: true
    },
    password: { 
        type: String,
        required: true
    },
    age: { 
        type: Number
    },
    famille: { 
        type: String
    },
    race: { 
        type: String
    },
    nourriture: { 
        type: String
    },
    amis: { 
        type: [ObjectId]
    },
    amisNonInscrit : [{
        nom: { 
            type: String,
            required: true
        },
        age: { 
            type: Number
        },
        famille: { 
            type: String
        },
        race: { 
            type: String
        },
        nourriture: { 
            type: String
        }
    }]
});

var Pangolin = mongoose.model('Pangolin', pangolinSchema);

module.exports = { Pangolin };