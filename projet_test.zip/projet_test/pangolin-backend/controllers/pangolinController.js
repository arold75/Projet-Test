var express = require('express');
var bodyParser = require('body-parser');
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
var ObjectId = require('mongoose').Types.ObjectId;

var config = require('../config');
var VerifyToken = require('../middlewares/VerifyToken');

var router = express.Router();
router.use(bodyParser.urlencoded({ extended: false }));
router.use(bodyParser.json());

var { Pangolin } = require('../models/pangolin');

/**
 * Get authenticated pangolin
 */
router.get('/profile', VerifyToken, function (req, res) {
  Pangolin.findById(req.pangolinId, { password: 0 }, function (err, pangolin) {
    if (err) return res.status(500).send("There was a problem finding the pangolin.");
    if (!pangolin) return res.status(404).send("No pangolin found.");
    res.status(200).send(pangolin);
  });
});

/**
 * Get all pangolins
 */
router.get('/allPangolins', VerifyToken, (req, res) => {
  Pangolin.find((err, docs) => {
      if (!err) { res.send(docs); }
      else { console.log('Error in retrieving pangolins :' + JSON.stringify(err, undefined, 2)); }
  });
});

/**
 * Get a pangolin by id
 */
router.get('/:id', VerifyToken, (req, res) => {
  if (!ObjectId.isValid(req.params.id))
      return res.status(400).send(`No record with given id : ${req.params.id}`);

  Pangolin.findById(req.params.id, (err, doc) => {
      if (!err) { res.send(doc); }
      else { console.log('Error in Retrieving Pangolin :' + JSON.stringify(err, undefined, 2)); }
  });
});


/**
 * Register a pangolin
 */
router.post('/register', function (req, res) {
  Pangolin.findOne({ login: req.body.login }, function (err, pangolin) {
    if (err) return res.status(500).send('Error on the server.');
    if (pangolin) return res.status(409).send({ auth: false, message: 'This login already exists.' });
    var hashedPassword = bcrypt.hashSync(req.body.password, 8);
    var pangolin = new Pangolin({
      login: req.body.login,
      password: hashedPassword
    });
    pangolin.save((error, pangolin) => {
      if (!error) {
        var token = jwt.sign({ id: pangolin._id }, config.secret, {
          expiresIn: 86400 // expires in 24 hours
        });
        res.status(200).send({ auth: true, token: token });
      }
      else { return res.status(500).send("There was a problem registering the pangolin."); }
    });
  });
});


/**
 * Register a pangolin
 */
router.post('/inscription', function (req, res) {
  Pangolin.findOne({ login: req.body.login }, function (err, pangolin) {
    if (err) return res.status(500).send('Error on the server.');
    if (pangolin) return res.status(409).send({ auth: false, message: 'This login already exists.' });
    var hashedPassword = bcrypt.hashSync(req.body.password, 8);

    var pangolin = new Pangolin({
      login: req.body.login,
      password: hashedPassword,
      age: req.body.age,
      famille: req.body.famille,
      race: req.body.race,
      nourriture: req.body.nourriture
    });
    pangolin.save((error, pangolin) => {
      if (!error) {
        var token = jwt.sign({ id: pangolin._id }, config.secret, {
          expiresIn: 86400 // expires in 24 hours
        });
        res.status(200).send({ auth: true, token: token });
      }
      else { return res.status(500).send("There was a problem registering the pangolin."); }
    });
  });
});



/**
 * Edit a pangolin
 */
router.put('/:id', VerifyToken, (req, res) => {
  if (!ObjectId.isValid(req.params.id))
      return res.status(400).send(`No record with given id : ${req.params.id}`);

  var pangolin = {
      name: req.body.name,
      age: req.body.age,
      famille: req.body.famille,
      race: req.body.race,
      nourriture: req.body.nourriture
  };
  if(req.body.password != undefined)
      pangolin.password = bcrypt.hashSync(req.body.password);
  Pangolin.findByIdAndUpdate(req.params.id, { $set: pangolin }, { new: true }, (err, doc) => {
      if (!err) { res.send(doc); }
      else { console.log('Error in Pangolin Update :' + JSON.stringify(err, undefined, 2)); }
  });
});

/**
 * Add a friend
 */
router.put('/addfriend/:id/:friendId', VerifyToken, (req, res) => {
  if (!ObjectId.isValid(req.params.id))
      return res.status(400).send(`No record with given id : ${req.params.id}`);
  if (!ObjectId.isValid(req.params.friendId))
      return res.status(400).send(`No record with given friend id : ${req.params.friendId}`);

  Pangolin.findById(req.params.id, (err, doc) => {
    if (!err) { 
        doc.amis.push(req.params.friendId);
        var pangolin = {
            amis: doc.amis
        };
        Pangolin.findByIdAndUpdate(req.params.id, { $set: pangolin }, { new: true }, (err, doc) => {
            if (!err) { res.send(doc); }
            else { console.log('Error in Adding Pangolin Friend :' + JSON.stringify(err, undefined, 2)); }
        });
    }
  });
});

/**
 * Delete a friend
 */
router.put('/deletefriend/:id/:friendId', VerifyToken, (req, res) => {
  if (!ObjectId.isValid(req.params.id))
      return res.status(400).send(`No record with given id : ${req.params.id}`);
  if (!ObjectId.isValid(req.params.friendId))
      return res.status(400).send(`No record with given friend id : ${req.params.friendId}`);

  Pangolin.findById(req.params.id, (err, doc) => {
    if (!err) { 
        doc.amis.splice(doc.amis.indexOf(req.params.friendId), 1);
        var pangolin = {
            amis: doc.amis
        };
        Pangolin.findByIdAndUpdate(req.params.id, { $set: pangolin }, { new: true }, (err, doc) => {
            if (!err) { res.send(doc); }
            else { console.log('Error in Deleting Pangolin Friend :' + JSON.stringify(err, undefined, 2)); }
        });
    }
  });
});

/**
 * Delete a pangolin
 */
router.delete('/:id', VerifyToken, (req, res) => {
  if (!ObjectId.isValid(req.params.id))
      return res.status(400).send(`No record with given id : ${req.params.id}`);

  Pangolin.findByIdAndRemove(req.params.id, (err, doc) => {
      if (!err) { res.send(doc); }
      else { console.log('Error in Pangolin Delete :' + JSON.stringify(err, undefined, 2)); }
  });
});

/**
 * Pangolin login
 */
router.post('/login', function (req, res) {
  Pangolin.findOne({ login: req.body.login }, function (err, pangolin) {
    if (err) return res.status(500).send('Error on the server.');
    if (!pangolin) return res.status(404).send('No pangolin found.');
    var passwordIsValid = bcrypt.compareSync(req.body.password, pangolin.password);
    if (!passwordIsValid) return res.status(401).send({ auth: false, token: null });
    var token = jwt.sign({ id: pangolin._id }, config.secret, {
      expiresIn: 86400 // expires in 24 hours
    });
   res.status(200).send({ auth: true, token: token });
  });
});

/**
 * ajouter un contact non inscrit
 */
router.put('/addfriendNonIncrit/:id', VerifyToken, (req, res) => {
  if (!ObjectId.isValid(req.params.id))
      return res.status(400).send(`No record with given id : ${req.params.id}`);

  Pangolin.findById(req.params.id, (err, doc) => {
    if (!err) { 
          var pangolinNonInscrit = {
            nom: req.body.nom,
            age: req.body.age,
            famille: req.body.famille,
            race: req.body.race,
            nourriture: req.body.nourriture
        };
        doc.amisNonInscrit.push(pangolinNonInscrit);
        var pangolin = {
            amisNonInscrit: doc.amisNonInscrit
        };
        Pangolin.findByIdAndUpdate(req.params.id, { $set: pangolin }, { new: true }, (err, doc) => {
            if (!err) { res.send(doc); }
            else { console.log('Error in Adding Pangolin Friend :' + JSON.stringify(err, undefined, 2)); }
        });
    }
  });
});
//

module.exports = router;