module.exports = {
    'secret': 'supersecret'
};